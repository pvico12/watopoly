#include "nonproperty.h"

NonProperty::NonProperty(std::string name)
    : Block{name} {}